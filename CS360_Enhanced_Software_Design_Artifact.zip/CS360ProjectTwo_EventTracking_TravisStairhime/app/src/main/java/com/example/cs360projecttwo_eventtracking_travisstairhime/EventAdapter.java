package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView adapter for displaying event rows.
 * Provides delete button handling and row click handling for editing.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    public interface OnEventActionListener {
        void onDelete(Event event);
        void onEdit(Event event);
    }

    private final List<Event> events;
    private final OnEventActionListener listener;

    public EventAdapter(List<Event> events, OnEventActionListener listener) {
        this.events = events;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = events.get(position);

        holder.title.setText(event.title);
        holder.date.setText(event.date);
        holder.time.setText(event.time);

        // Delete button per row (rubric requirement)
        holder.deleteButton.setOnClickListener(v -> listener.onDelete(event));

        // Tap row to edit (Update requirement)
        holder.itemView.setOnClickListener(v -> listener.onEdit(event));
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView date;
        TextView time;
        Button deleteButton;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textRowTitle);
            date = itemView.findViewById(R.id.textRowDate);
            time = itemView.findViewById(R.id.textRowTime);
            deleteButton = itemView.findViewById(R.id.buttonDeleteEvent);
        }
    }
}
