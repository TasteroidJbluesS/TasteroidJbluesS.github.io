package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * AddEventActivity supports:
 * - Create: insert a new event
 * - Update: edit an existing event when an event ID is provided
 *
 * Enhancement notes:
 * - Uses shared constants instead of repeated intent key strings.
 * - Uses ValidationUtils for reusable, consistent validation.
 * - Uses defensive cursor handling when loading existing records.
 */
public class AddEventActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    private EditText editTitle;
    private EditText editDate;
    private EditText editTime;
    private EditText editNotes;

    // If INVALID_EVENT_ID, this screen creates a new event. Otherwise, it edits an event.
    private int eventId = AppConstants.INVALID_EVENT_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dbHelper = new DBHelper(this);
        bindViews();
        configureButtons();
        loadEventIdFromIntent();
    }

    /** Links activity fields to XML layout controls. */
    private void bindViews() {
        editTitle = findViewById(R.id.editEventTitle);
        editDate = findViewById(R.id.editEventDate);
        editTime = findViewById(R.id.editEventTime);
        editNotes = findViewById(R.id.editEventNotes);
    }

    /** Configures button actions in one place to keep onCreate easier to read. */
    private void configureButtons() {
        Button buttonCancel = findViewById(R.id.buttonCancelAddEvent);
        Button buttonSave = findViewById(R.id.buttonSaveEvent);

        buttonCancel.setOnClickListener(v -> finish());
        buttonSave.setOnClickListener(v -> saveEvent());
    }

    /** Checks whether this screen was opened to edit an existing event. */
    private void loadEventIdFromIntent() {
        if (getIntent() != null && getIntent().hasExtra(AppConstants.EXTRA_EVENT_ID)) {
            eventId = getIntent().getIntExtra(
                    AppConstants.EXTRA_EVENT_ID,
                    AppConstants.INVALID_EVENT_ID
            );

            if (eventId != AppConstants.INVALID_EVENT_ID) {
                loadEvent(eventId);
            }
        }
    }

    /** Loads an existing event from the database and fills the form fields. */
    private void loadEvent(int id) {
        Cursor cursor = null;
        try {
            cursor = dbHelper.getEventById(id);
            if (cursor != null && cursor.moveToFirst()) {
                editTitle.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TITLE)));
                editDate.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_DATE)));
                editTime.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TIME)));
                editNotes.setText(cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_NOTES)));
            } else {
                Toast.makeText(this, "Event could not be loaded.", Toast.LENGTH_SHORT).show();
                finish();
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /** Creates a new event or updates an existing one depending on eventId. */
    private void saveEvent() {
        String title = editTitle.getText().toString().trim();
        String date = editDate.getText().toString().trim();
        String time = editTime.getText().toString().trim();
        String notes = editNotes.getText().toString().trim();

        String validationError = ValidationUtils.validateEventInput(title, date, time, notes);
        if (validationError != null) {
            Toast.makeText(this, validationError, Toast.LENGTH_SHORT).show();
            return;
        }

        if (eventId == AppConstants.INVALID_EVENT_ID) {
            addEvent(title, date, time, notes);
        } else {
            updateEvent(title, date, time, notes);
        }
    }

    /** Attempts to create a new event and gives the user clear feedback. */
    private void addEvent(String title, String date, String time, String notes) {
        long newId = dbHelper.addEvent(title, date, time, notes);
        if (newId != -1) {
            Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Add failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /** Attempts to update an existing event and gives the user clear feedback. */
    private void updateEvent(String title, String date, String time, String notes) {
        boolean updated = dbHelper.updateEvent(eventId, title, date, time, notes);
        if (updated) {
            Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Update failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
