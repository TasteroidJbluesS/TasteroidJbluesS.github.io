package com.example.cs360projecttwo_eventtracking_travisstairhime;

/**
 * Model class representing a single event record from the database.
 * The fields are final so event objects remain predictable after creation.
 */
public class Event {
    public final int id;
    public final String title;
    public final String date;
    public final String time;
    public final String notes;

    public Event(int id, String title, String date, String time, String notes) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.notes = notes;
    }
}
