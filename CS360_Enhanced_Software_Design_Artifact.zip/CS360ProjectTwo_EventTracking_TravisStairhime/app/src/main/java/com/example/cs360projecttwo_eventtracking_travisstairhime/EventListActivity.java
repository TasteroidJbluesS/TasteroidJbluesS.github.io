package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Displays all events in a RecyclerView list (Read).
 * Supports deleting rows (Delete) and tapping a row to edit (Update).
 *
 * Enhancement notes:
 * - Adds confirmation before deleting an event.
 * - Uses shared constants for intent extras.
 * - Uses defensive cursor handling when loading database records.
 */
public class EventListActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    private RecyclerView recyclerEvents;
    private EventAdapter adapter;
    private final ArrayList<Event> events = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DBHelper(this);
        configureRecyclerView();
        configureButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents(); // Refresh after returning from Add/Edit screen
    }

    /** Sets up the RecyclerView and row-level edit/delete callbacks. */
    private void configureRecyclerView() {
        recyclerEvents = findViewById(R.id.recyclerEvents);
        recyclerEvents.setLayoutManager(new LinearLayoutManager(this));

        adapter = new EventAdapter(events, new EventAdapter.OnEventActionListener() {
            @Override
            public void onDelete(Event event) {
                confirmDelete(event);
            }

            @Override
            public void onEdit(Event event) {
                openEditEvent(event);
            }
        });

        recyclerEvents.setAdapter(adapter);
    }

    /** Configures top-level screen navigation buttons. */
    private void configureButtons() {
        Button buttonAddEvent = findViewById(R.id.buttonAddEvent);
        Button buttonSmsReminders = findViewById(R.id.buttonSmsReminders);

        buttonAddEvent.setOnClickListener(v -> openAddEvent());
        buttonSmsReminders.setOnClickListener(v -> openNotifications());
    }

    /** Opens the add-event screen in create mode. */
    private void openAddEvent() {
        startActivity(new Intent(EventListActivity.this, AddEventActivity.class));
    }

    /** Opens the notification screen. */
    private void openNotifications() {
        startActivity(new Intent(EventListActivity.this, NotificationsActivity.class));
    }

    /** Opens the add-event screen in edit mode. */
    private void openEditEvent(Event event) {
        Intent intent = new Intent(EventListActivity.this, AddEventActivity.class);
        intent.putExtra(AppConstants.EXTRA_EVENT_ID, event.id);
        startActivity(intent);
    }

    /** Confirms destructive delete actions before modifying the database. */
    private void confirmDelete(Event event) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage("Delete " + event.title + "?")
                .setPositiveButton("Delete", (dialog, which) -> deleteEvent(event))
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Deletes an event and refreshes the list when successful. */
    private void deleteEvent(Event event) {
        boolean deleted = dbHelper.deleteEvent(event.id);
        if (deleted) {
            Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
            loadEvents();
        } else {
            Toast.makeText(this, "Delete failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /** Loads all events from SQLite and refreshes the RecyclerView. */
    private void loadEvents() {
        events.clear();

        Cursor cursor = null;
        try {
            cursor = dbHelper.getAllEvents();
            while (cursor != null && cursor.moveToNext()) {
                events.add(readEventFromCursor(cursor));
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        adapter.notifyDataSetChanged();
    }

    /** Converts one database cursor row into an Event object. */
    private Event readEventFromCursor(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_ID));
        String title = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TITLE));
        String date = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_DATE));
        String time = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TIME));
        String notes = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_NOTES));

        return new Event(id, title, date, time, notes);
    }
}
