package com.example.cs360projecttwo_eventtracking_travisstairhime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Reusable validation helpers for user input.
 * Moving validation into a shared utility reduces repeated logic across
 * activities and supports more consistent defensive programming.
 */
public final class ValidationUtils {

    private ValidationUtils() {
        // Utility class; no instances needed.
    }

    public static String validateCredentials(String username, String password, boolean creatingAccount) {
        if (isBlank(username) || isBlank(password)) {
            return creatingAccount
                    ? "Enter a username and password to create an account."
                    : "Please enter a username and password.";
        }

        if (creatingAccount && password.trim().length() < AppConstants.MIN_PASSWORD_LENGTH) {
            return "Password must be at least " + AppConstants.MIN_PASSWORD_LENGTH + " characters.";
        }

        return null;
    }

    public static String validateEventInput(String title, String date, String time, String notes) {
        if (isBlank(title) || isBlank(date) || isBlank(time)) {
            return "Title, date, and time are required.";
        }

        if (title.trim().length() > AppConstants.MAX_TITLE_LENGTH) {
            return "Title must be " + AppConstants.MAX_TITLE_LENGTH + " characters or fewer.";
        }

        if (!isValidDate(date)) {
            return "Date must use MM/DD/YYYY format.";
        }

        if (!isValidTime(time)) {
            return "Time must use a format like 2:30 PM.";
        }

        if (notes != null && notes.trim().length() > AppConstants.MAX_NOTES_LENGTH) {
            return "Notes must be " + AppConstants.MAX_NOTES_LENGTH + " characters or fewer.";
        }

        return null;
    }

    public static String validatePhoneNumber(String phone) {
        if (isBlank(phone)) {
            return "Please enter a phone number.";
        }

        String normalizedPhone = normalizePhoneNumber(phone);
        if (!normalizedPhone.matches(AppConstants.PHONE_PATTERN)) {
            return "Enter a valid phone number using digits only.";
        }

        return null;
    }

    public static String normalizePhoneNumber(String phone) {
        if (phone == null) {
            return "";
        }
        return phone.replaceAll("[\\s()\\-]", "").trim();
    }

    public static String safeTrim(String value) {
        return value == null ? "" : value.trim();
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static boolean isValidDate(String date) {
        SimpleDateFormat formatter = new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.US);
        formatter.setLenient(false);
        try {
            formatter.parse(date.trim());
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private static boolean isValidTime(String time) {
        return time != null && time.trim().matches(AppConstants.TIME_PATTERN);
    }
}
