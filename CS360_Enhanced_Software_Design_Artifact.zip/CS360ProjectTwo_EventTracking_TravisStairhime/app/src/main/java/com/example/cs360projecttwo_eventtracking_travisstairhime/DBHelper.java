package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DBHelper creates and manages the app's SQLite database.
 * This class centralizes database operations so the activities do not need to
 * build SQL statements directly.
 *
 * Note: This course project stores passwords in plain text for simplicity.
 * In a production application, credentials should be hashed and salted instead.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "event_tracker.db";
    private static final int DB_VERSION = 1;

    // ----- USERS TABLE -----
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // ----- EVENTS TABLE -----
    public static final String TABLE_EVENTS = "events";
    public static final String COL_EVENT_ID = "id";
    public static final String COL_TITLE = "title";
    public static final String COL_DATE = "date";   // store as TEXT: "MM/DD/YYYY"
    public static final String COL_TIME = "time";   // store as TEXT: "h:mm AM/PM"
    public static final String COL_NOTES = "notes";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");";

        String createEvents =
                "CREATE TABLE " + TABLE_EVENTS + " (" +
                        COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_TITLE + " TEXT NOT NULL, " +
                        COL_DATE + " TEXT NOT NULL, " +
                        COL_TIME + " TEXT NOT NULL, " +
                        COL_NOTES + " TEXT" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple class-project upgrade strategy: rebuild tables.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // -------------------- USER METHODS --------------------

    /** Returns true if a user row was created successfully. */
    public boolean createUser(String username, String password) {
        String cleanUsername = ValidationUtils.safeTrim(username);
        String cleanPassword = ValidationUtils.safeTrim(password);

        if (cleanUsername.isEmpty() || cleanPassword.isEmpty()) {
            return false;
        }

        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_USERNAME, cleanUsername);
            values.put(COL_PASSWORD, cleanPassword);
            long result = db.insert(TABLE_USERS, null, values);
            return result != -1;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Returns true if a matching username/password row exists. */
    public boolean validateUser(String username, String password) {
        String cleanUsername = ValidationUtils.safeTrim(username);
        String cleanPassword = ValidationUtils.safeTrim(password);

        if (cleanUsername.isEmpty() || cleanPassword.isEmpty()) {
            return false;
        }

        Cursor cursor = null;
        try {
            SQLiteDatabase db = getReadableDatabase();
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{cleanUsername, cleanPassword},
                    null, null, null
            );
            return cursor.moveToFirst();
        } catch (SQLException e) {
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /** Returns true if the username already exists. */
    public boolean userExists(String username) {
        String cleanUsername = ValidationUtils.safeTrim(username);

        if (cleanUsername.isEmpty()) {
            return false;
        }

        Cursor cursor = null;
        try {
            SQLiteDatabase db = getReadableDatabase();
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{cleanUsername},
                    null, null, null
            );
            return cursor.moveToFirst();
        } catch (SQLException e) {
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    // -------------------- EVENT CRUD METHODS --------------------

    /** Create: add an event row and return the new row ID, or -1 if failed. */
    public long addEvent(String title, String date, String time, String notes) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            return db.insert(TABLE_EVENTS, null, buildEventValues(title, date, time, notes));
        } catch (SQLException e) {
            return -1;
        }
    }

    /** Read: return all events sorted by date and time. Caller must close cursor. */
    public Cursor getAllEvents() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE_EVENTS, null, null, null, null, null,
                COL_DATE + " ASC, " + COL_TIME + " ASC");
    }

    /** Read: return events that match a specific date. Caller must close cursor. */
    public Cursor getEventsByDate(String date) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_EVENTS,
                null,
                COL_DATE + "=?",
                new String[]{ValidationUtils.safeTrim(date)},
                null, null,
                COL_TIME + " ASC"
        );
    }

    /** Read one event by id. Caller must close cursor. */
    public Cursor getEventById(int eventId) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_EVENTS,
                null,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(eventId)},
                null, null, null
        );
    }

    /** Update: change an existing event row. */
    public boolean updateEvent(int id, String title, String date, String time, String notes) {
        if (id == AppConstants.INVALID_EVENT_ID) {
            return false;
        }

        try {
            SQLiteDatabase db = getWritableDatabase();
            int rows = db.update(TABLE_EVENTS, buildEventValues(title, date, time, notes),
                    COL_EVENT_ID + "=?", new String[]{String.valueOf(id)});
            return rows > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Delete: remove an event row by id. */
    public boolean deleteEvent(int id) {
        if (id == AppConstants.INVALID_EVENT_ID) {
            return false;
        }

        try {
            SQLiteDatabase db = getWritableDatabase();
            int rows = db.delete(TABLE_EVENTS, COL_EVENT_ID + "=?",
                    new String[]{String.valueOf(id)});
            return rows > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Builds ContentValues in one reusable place to avoid repeated database mapping logic. */
    private ContentValues buildEventValues(String title, String date, String time, String notes) {
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, ValidationUtils.safeTrim(title));
        values.put(COL_DATE, ValidationUtils.safeTrim(date));
        values.put(COL_TIME, ValidationUtils.safeTrim(time));
        values.put(COL_NOTES, ValidationUtils.safeTrim(notes));
        return values;
    }
}
