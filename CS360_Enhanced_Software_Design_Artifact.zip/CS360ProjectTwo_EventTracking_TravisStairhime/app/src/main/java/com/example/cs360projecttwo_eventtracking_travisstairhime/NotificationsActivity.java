package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Handles SMS permission requests and sends event reminders if permission is granted.
 *
 * Enhancement notes:
 * - Validates phone numbers before attempting to send SMS messages.
 * - Queries only today's events instead of loading every event and filtering in the activity.
 * - Uses defensive cursor handling and smaller helper methods.
 */
public class NotificationsActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private TextView textPermissionStatus;
    private EditText editPhoneNumber;

    // Runtime permission launcher
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionLabel(isGranted);
                Toast.makeText(this,
                        isGranted ? "SMS permission granted." : "SMS permission denied.",
                        Toast.LENGTH_SHORT).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        dbHelper = new DBHelper(this);
        bindViews();
        configureButtons();
        updatePermissionLabel(hasSmsPermission());
    }

    /** Links activity fields to XML layout controls. */
    private void bindViews() {
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
    }

    /** Configures SMS and back button behavior. */
    private void configureButtons() {
        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonBack = findViewById(R.id.buttonBackFromSms);

        buttonEnableSms.setOnClickListener(v -> handleSmsButton());
        buttonBack.setOnClickListener(v -> finish());
    }

    /** Requests permission when needed or sends reminders when permission already exists. */
    private void handleSmsButton() {
        if (!hasSmsPermission()) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        } else {
            sendTodaysReminders();
        }
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionLabel(boolean granted) {
        textPermissionStatus.setText(
                granted ? "SMS Permission: Granted" : "SMS Permission: Not Granted"
        );
    }

    /** Sends SMS reminders for events scheduled for today. */
    private void sendTodaysReminders() {
        String phone = ValidationUtils.normalizePhoneNumber(editPhoneNumber.getText().toString());
        String validationError = ValidationUtils.validatePhoneNumber(phone);

        if (validationError != null) {
            Toast.makeText(this, validationError, Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = null;
        boolean sentAny = false;

        try {
            cursor = dbHelper.getEventsByDate(getTodayDate());
            while (cursor != null && cursor.moveToNext()) {
                sentAny = sendReminderForCursorRow(cursor, phone) || sentAny;
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        Toast.makeText(this,
                sentAny ? "Reminder sent." : "No events scheduled for today.",
                Toast.LENGTH_SHORT).show();
    }

    /** Sends a reminder message for the event represented by the current cursor row. */
    private boolean sendReminderForCursorRow(Cursor cursor, String phone) {
        String title = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TITLE));
        String time = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_TIME));
        String message = "Reminder: " + title + " today at " + time;

        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            return true;
        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS failed. This may be an emulator limitation.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private String getTodayDate() {
        return new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.US).format(new Date());
    }
}
