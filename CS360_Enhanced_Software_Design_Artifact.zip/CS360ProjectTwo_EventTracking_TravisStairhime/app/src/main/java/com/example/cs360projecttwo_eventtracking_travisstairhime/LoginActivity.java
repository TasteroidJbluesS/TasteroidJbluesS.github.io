package com.example.cs360projecttwo_eventtracking_travisstairhime;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles user login and account creation.
 * Uses SQLite database (DBHelper) for persistent storage.
 *
 * Enhancement notes:
 * - Uses shared validation for consistent credential checks.
 * - Keeps UI, validation, and database actions in smaller methods.
 */
public class LoginActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText editUsername;
    private EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);
        bindViews();
        configureButtons();
    }

    /** Links activity fields to XML layout controls. */
    private void bindViews() {
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
    }

    /** Configures button actions in one place to keep onCreate focused. */
    private void configureButtons() {
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> handleLogin());
        buttonCreateAccount.setOnClickListener(v -> handleCreateAccount());
    }

    /** Checks username and password against the database. */
    private void handleLogin() {
        String username = getUsername();
        String password = getPassword();

        String validationError = ValidationUtils.validateCredentials(username, password, false);
        if (validationError != null) {
            Toast.makeText(this, validationError, Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.validateUser(username, password)) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, EventListActivity.class));
        } else {
            Toast.makeText(this,
                    "Invalid credentials. Try again or create an account.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /** Creates a new account if username does not already exist. */
    private void handleCreateAccount() {
        String username = getUsername();
        String password = getPassword();

        String validationError = ValidationUtils.validateCredentials(username, password, true);
        if (validationError != null) {
            Toast.makeText(this, validationError, Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.userExists(username)) {
            Toast.makeText(this, "Username already exists. Please log in.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = dbHelper.createUser(username, password);
        Toast.makeText(this,
                created ? "Account created successfully." : "Account creation failed.",
                Toast.LENGTH_SHORT).show();
    }

    private String getUsername() {
        return editUsername.getText().toString().trim();
    }

    private String getPassword() {
        return editPassword.getText().toString().trim();
    }
}
