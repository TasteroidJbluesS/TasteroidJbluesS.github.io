package com.example.cs360projecttwo_eventtracking_travisstairhime;

/**
 * Central location for values reused across multiple activities.
 * Keeping shared constants here reduces duplicated strings and makes future
 * maintenance safer because updates only need to be made in one place.
 */
public final class AppConstants {

    public static final String EXTRA_EVENT_ID = "EVENT_ID";
    public static final int INVALID_EVENT_ID = -1;

    public static final int MIN_PASSWORD_LENGTH = 6;
    public static final int MAX_TITLE_LENGTH = 60;
    public static final int MAX_NOTES_LENGTH = 250;

    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String TIME_PATTERN = "(?i)^(1[0-2]|0?[1-9]):[0-5][0-9]\\s?(AM|PM)$";
    public static final String PHONE_PATTERN = "^[+]?[0-9]{10,15}$";

    private AppConstants() {
        // Utility class; no instances needed.
    }
}
