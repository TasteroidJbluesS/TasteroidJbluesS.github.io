Database Enhancements:
1. Added schema validation rules.
2. Converted perPerson from String to Number.
3. Added unique constraint on trip code.
4. Added compound index on resort and start date.
5. Added search endpoint for filtered trip retrieval.
