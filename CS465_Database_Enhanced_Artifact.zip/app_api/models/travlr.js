const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        unique: true,
        index: true,
        trim: true,
        uppercase: true
    },
    name: { type: String, required: true, index: true, trim: true },
    length: { type: String, required: true },
    start: { type: Date, required: true },
    resort: { type: String, required: true, trim: true },
    perPerson: { type: Number, required: true, min: 0 },
    image: { type: String, required: true },
    description: { type: String, required: true, maxlength: 1000 }
});

tripSchema.index({ resort: 1, start: 1 });

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
