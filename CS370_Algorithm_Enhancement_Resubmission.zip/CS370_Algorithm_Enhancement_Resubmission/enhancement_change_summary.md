# Enhancement Change Summary

The CS 370 Pirate Intelligent Agent artifact was enhanced through actual algorithmic and data-structure changes rather than documentation-only improvements.

## Original Approach

The original project trained a pirate agent using Deep Q-Learning. The agent selected actions using an epsilon-greedy strategy, stored experiences in replay memory, and trained a neural network to estimate Q-values for available movement actions.

## Enhanced Approach

The updated implementation improves the reinforcement learning process in three main ways:

1. **Adaptive exploration:** The epsilon value now changes based on recent win-rate performance instead of following only one fixed decay pattern.
2. **Reward shaping:** The training reward now gives additional feedback based on whether the agent moves closer to or farther from the treasure.
3. **Visited-state tracking:** A set now tracks cells visited during each episode so repeated states can be detected efficiently and penalized.

## Why These Changes Fit Algorithms and Data Structures

These enhancements directly affect the learning algorithm and the data structures used by the agent. Adaptive epsilon decay changes the decision-making strategy. Reward shaping changes the reinforcement learning update signal. The visited-state set introduces a hash-based data structure that improves repeated-state detection and discourages inefficient looping behavior.

## Expected Benefit

Together, these changes are designed to improve training efficiency, path quality, and learning stability. The enhanced agent is not only encouraged to reach the treasure, but to do so with fewer repeated movements and a more efficient learned path.
