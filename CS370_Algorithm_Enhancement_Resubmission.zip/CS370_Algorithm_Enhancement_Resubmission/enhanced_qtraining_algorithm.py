"""
CS 370 Pirate Intelligent Agent - Algorithms and Data Structures Enhancement
Author: Travis Stairhime

Purpose:
This file contains an enhanced version of the qtrain() reinforcement learning routine
for the CS 370 Pirate Intelligent Agent artifact. The enhancements are technical
algorithm/data-structure changes rather than documentation-only changes.

Enhancements implemented:
1. Adaptive epsilon decay based on recent win-rate performance.
2. Reward shaping using Manhattan-distance progress toward the treasure.
3. A hash-based visited-state set to detect repeated states in O(1) average time.
4. Additional path-efficiency metrics for evaluating training behavior.

Integration note:
This code is designed to replace the qtrain() block in the original notebook. It
assumes the original project still provides TreasureMaze, GameExperience, clone_model,
train_step(), completion_check(), format_time(), and actions_dict/num_actions.
"""

import datetime
import random
from collections import deque

import numpy as np


# -----------------------------------------------------------------------------
# Enhancement constants
# -----------------------------------------------------------------------------
REVISIT_PENALTY = -0.20          # discourages loops and repeated cells
PROGRESS_REWARD = 0.10           # rewards movement closer to treasure
REGRESS_PENALTY = -0.05          # penalizes movement farther from treasure
MIN_EPSILON = 0.05               # minimum exploration value
BASE_EPSILON_DECAY = 0.995       # default decay when learning is unstable
FAST_EPSILON_DECAY = 0.985       # faster decay once performance improves
SLOW_EPSILON_DECAY = 0.998       # slower decay when performance stagnates
PERFORMANCE_WINDOW = 32          # rolling window used to evaluate win rate


def state_to_cell(env_state):
    """Convert a flattened maze state into the pirate's current cell.

    The original TreasureMaze environment represents the current environment state
    as a flattened matrix. The pirate's location is represented by a unique value
    in that state. This helper attempts to recover the pirate cell in a way that
    works with the original CS 370 notebook format.
    """
    state = np.asarray(env_state).reshape(-1)
    pirate_index = int(np.argmin(state)) if state.size else 0
    side_length = int(np.sqrt(state.size))
    return divmod(pirate_index, side_length)


def manhattan_distance(cell, goal_cell):
    """Return Manhattan distance between two maze cells."""
    return abs(cell[0] - goal_cell[0]) + abs(cell[1] - goal_cell[1])


def shape_reward(base_reward, previous_cell, current_cell, goal_cell, visited_states):
    """Apply reward shaping to encourage efficient paths.

    Algorithmic enhancement:
    The original Q-learning implementation used the environment reward directly.
    This function modifies the reward signal by adding small feedback values for
    progress toward or away from the treasure and by penalizing repeated states.

    Data-structure enhancement:
    visited_states is a Python set. Membership checks are O(1) on average, making
    repeated-state detection efficient even as path length grows.
    """
    shaped_reward = base_reward

    previous_distance = manhattan_distance(previous_cell, goal_cell)
    current_distance = manhattan_distance(current_cell, goal_cell)

    if current_distance < previous_distance:
        shaped_reward += PROGRESS_REWARD
    elif current_distance > previous_distance:
        shaped_reward += REGRESS_PENALTY

    if current_cell in visited_states:
        shaped_reward += REVISIT_PENALTY

    return shaped_reward


def update_epsilon(epsilon, recent_win_rate):
    """Adapt exploration rate based on learning performance.

    Algorithmic enhancement:
    The original implementation used a fixed epsilon decay schedule. This adaptive
    schedule changes exploration pressure based on the agent's recent win rate.
    Low win rates keep exploration high longer. Higher win rates reduce exploration
    more quickly so the agent can exploit successful paths.
    """
    if recent_win_rate >= 0.85:
        decay = FAST_EPSILON_DECAY
    elif recent_win_rate <= 0.35:
        decay = SLOW_EPSILON_DECAY
    else:
        decay = BASE_EPSILON_DECAY

    return max(epsilon * decay, MIN_EPSILON)


def qtrain_enhanced(model, maze, **opt):
    """Enhanced Deep Q-Learning training loop for the Pirate Intelligent Agent.

    This version keeps the original Deep Q-Learning structure while adding real
    algorithms/data-structure enhancements:
    - adaptive epsilon scheduling,
    - reward shaping,
    - repeated-state tracking with a set,
    - and path-efficiency metrics.
    """
    global epsilon

    n_epoch = opt.get('n_epoch', 15000)
    max_memory = opt.get('max_memory', 1000)
    data_size = opt.get('data_size', 50)
    target_update_freq = opt.get('target_update_freq', 50)

    start_time = datetime.datetime.now()
    qmaze = TreasureMaze(maze)
    goal_cell = (qmaze.maze.shape[0] - 1, qmaze.maze.shape[1] - 1)

    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())
    experience = GameExperience(model, target_model, max_memory=max_memory)

    win_history = []
    recent_results = deque(maxlen=PERFORMANCE_WINDOW)
    path_lengths = []
    hsize = qmaze.maze.size // 2
    win_rate = 0.0

    for epoch in range(n_epoch):
        loss = 0.0
        n_episodes = 0
        step_count = 0

        # Reset at a random free cell.
        agent_cell = random.choice(qmaze.free_cells)
        qmaze.reset(agent_cell)
        env_state = qmaze.observe()
        game_over = False

        # Data-structure enhancement: track visited states with a hash set.
        visited_states = {tuple(agent_cell)}
        previous_cell = tuple(agent_cell)

        while not game_over:
            previous_envstate = env_state
            valid_actions = qmaze.valid_actions()

            if not valid_actions:
                win_history.append(0)
                recent_results.append(0)
                break

            # Epsilon-greedy action selection.
            if np.random.rand() < epsilon:
                action = random.choice(valid_actions)
            else:
                q_values = experience.predict(previous_envstate)
                action = int(np.argmax(q_values))
                if action not in valid_actions:
                    action = random.choice(valid_actions)

            # Environment transition.
            env_state, reward, game_status = qmaze.act(action)
            current_cell = state_to_cell(env_state)

            # Algorithmic enhancement: use shaped reward in replay memory.
            shaped_reward = shape_reward(
                base_reward=reward,
                previous_cell=previous_cell,
                current_cell=current_cell,
                goal_cell=goal_cell,
                visited_states=visited_states
            )

            visited_states.add(current_cell)
            previous_cell = current_cell
            step_count += 1

            if game_status == 'win':
                win_history.append(1)
                recent_results.append(1)
                path_lengths.append(step_count)
                game_over = True
            elif game_status == 'lose':
                win_history.append(0)
                recent_results.append(0)
                path_lengths.append(step_count)
                game_over = True

            # Store enhanced reward in replay memory.
            episode = [previous_envstate, action, shaped_reward, env_state, game_status]
            experience.remember(episode)

            inputs, targets = experience.get_data(batch_size=data_size)
            batch_loss = train_step(inputs, targets)

            try:
                batch_loss_value = float(batch_loss)
            except TypeError:
                batch_loss_value = float(batch_loss.numpy())

            loss += batch_loss_value
            n_episodes += 1

        # Periodically sync target network.
        if epoch % target_update_freq == 0:
            target_model.set_weights(model.get_weights())

        # Calculate recent performance and adapt epsilon.
        win_rate = sum(win_history[-hsize:]) / hsize if len(win_history) >= hsize else 0.0
        recent_win_rate = sum(recent_results) / len(recent_results) if recent_results else 0.0
        epsilon = update_epsilon(epsilon, recent_win_rate)

        avg_path_length = sum(path_lengths[-PERFORMANCE_WINDOW:]) / min(len(path_lengths), PERFORMANCE_WINDOW) if path_lengths else 0.0

        dt = datetime.datetime.now() - start_time
        t = format_time(dt.total_seconds())
        print(
            "Epoch: {:03d}/{:d} | Loss: {:.4f} | Episodes: {:d} | "
            "Win count: {:d} | Win rate: {:.3f} | Recent win rate: {:.3f} | "
            "Epsilon: {:.3f} | Avg path length: {:.2f} | time: {}".format(
                epoch, n_epoch - 1, loss, n_episodes, sum(win_history),
                win_rate, recent_win_rate, epsilon, avg_path_length, t
            )
        )

        if win_rate >= 0.999 and completion_check(model, maze):
            print(f"Reached 100% win rate at epoch {epoch}")
            break

    total_time = format_time((datetime.datetime.now() - start_time).total_seconds())
    print("Training complete in:", total_time)
